import logo from './logo.svg';
import './App.css';

import React,{useState,useEffect} from 'react'
import axios from 'axios';

import DisplayName from './components/DisplayName';

import MovieList from './components/MovieList';

import Speedometer from './components/Speedometer';

import Food from './components/Food';

import SimpleForm from './components/SimpleForm';

function App() {
  

  return (
    <div className="App">
      {/* <SimpleForm/> */}
    </div>
  )
}




export default App;
