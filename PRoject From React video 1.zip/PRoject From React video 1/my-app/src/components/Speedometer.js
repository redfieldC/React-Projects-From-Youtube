import React,{useState, useEffect} from 'react'

const Speedometer = () => {
    const [speed,setSpeed] = useState(20);

    const [counter,setCounter] = useState(0);

    function speedIncrease(){
        setSpeed(speed+10);
        console.log(speed);
    }

    // function increaseCounter(){
    //     setCounter(counter + 1);
    // }


    // function decreaseCounter(){
    //     setCounter(counter - 1);
    // }

    function speedDecrease(){
        setSpeed(speed-10);
        console.log(speed);
    }

    useEffect(() =>{
        console.log('counter has been changed ameya..........')
    },[counter])

    useEffect(()=>{
        console.log('speed has been changed to',speed ,' ameya........')
        return(()=>{
            console.log('speed from return ',speed ,' ameya........')
        })
    },[speed])

    useEffect(()=>{
        console.log('speedometer has been enabled and user is online')
        return (() => {
            console.log('speedometer has been disabled and user is offline')
        })
    },[])

    useEffect(()=>{
        console.log('Speed or Counter changed to ',speed,counter)
        return() =>{
            console.log('Old values of Speed or Counter changed to ',speed,counter)
        }
    },[speed,counter])


  return (
    <div>
        <h1>Speedometer</h1>
        <h1>Speed is : {speed}</h1>
        <hr />
        <h1>Counter is : {counter}</h1>
        <button onClick={speedIncrease}>Increase the speed by 10</button>
        <hr />
        <button onClick={speedDecrease}>Decrease the speed by 10</button>
        <hr />
        <button onClick={() => setCounter(counter + 1)}>increase Counter</button>
        <hr />
        <button onClick={() => setCounter(counter - 1)}>decrease Counter</button>
        {/*  */}
    </div>
  )
}

export default Speedometer