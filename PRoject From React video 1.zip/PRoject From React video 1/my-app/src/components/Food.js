import React from 'react'

const Food = () => {
  return (
    <>
    <div>Food</div>
    <div className="container">
        <h1>Surmai</h1>
        <h1>Birda Bhaat Bhaji</h1>
        <h1>KFC</h1>
        <h1>Subway</h1>
    </div>
    </>
  )
}

export default Food