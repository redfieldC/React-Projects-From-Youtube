import React, { useState } from 'react'

const SimpleForm = () => {
    const [name, setName] = useState('')
    const [isChecked, setIsChecked] = useState(false);
    const [favFruit, setFavFruit] = useState('mango');

    function handleSubmit(e) {
        e.preventDefault();
        console.log("Form submitted with value",{name , isChecked,favFruit});

    }
    return (
        <div>
            <h1>SimpleForm</h1>
            <form onSubmit={handleSubmit}>
                <label htmlFor="name">Name</label>
                <input type="text" id='name' value={name} onChange={(e) => setName(e.target.value)} />
                <br />
                <label htmlFor="checkbox">Are you happy?</label>
                <input type="checkbox" id="checkbox" checked={isChecked} onChange={(e) => setIsChecked(e.target.checked)} />
                <br />
                <label htmlFor="favFruit">What's your favourite Fruit?</label>
                <select  id="favFruit" value={favFruit} onChange={(e) => setFavFruit(e.target.value)}>
                    <option value="mango">Mango</option>
                    <option value="apple">Apple</option>
                    <option value="banana">Banana</option>
                    <option value="pomogrenade">Pomogrenade</option>
                </select>
                <br />

                <input type="submit" value="Submit form" />
            </form>
        </div>

    )
}

export default SimpleForm