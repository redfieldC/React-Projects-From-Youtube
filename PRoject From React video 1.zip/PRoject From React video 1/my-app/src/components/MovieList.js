import React from 'react'

const MovieList = ({movies,onclick}) => {
    // const movie_list = ['One piece', 'Naruto', 'Dragon Ball'];
    
    const list_of_movies = movies.map(movie => {
        return (
            <li key={movie.id} onClick={onclick}>{movie.name}</li>
        )
    })
    return (
        <div>
            <h1>MovieList</h1>
            <ul>
                {list_of_movies}
            </ul>
        </div>
    )
}

export default MovieList