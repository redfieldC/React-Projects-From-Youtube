import React from 'react'

const Addition = () => {
  return (
    <div>Addition</div>
  )
}

export default Addition