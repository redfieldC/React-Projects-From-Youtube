function DisplayName(){
    const surname = "Rege";
    return(
      <div>
        <h1>His surname is {surname}</h1>
      </div>
    )
  }

  


  export default DisplayName
